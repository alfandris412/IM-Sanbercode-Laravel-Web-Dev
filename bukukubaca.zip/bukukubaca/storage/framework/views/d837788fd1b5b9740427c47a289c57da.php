

<?php $__env->startSection("title"); ?>
    Tampil Genre
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <?php if(auth()->guard()->check()): ?> <?php if(Auth()->user()->role == 'admin'): ?>
    <a href="/genre/create" class="btn btn-primary my-3">Tambah</a>
    <?php endif; ?>
    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->nama); ?></td>
                    <td>
                    <form action="/genre/<?php echo e($item->id); ?>" method="post">
                    <a href="/genre/<?php echo e($item->id); ?>" class="btn btn-primary btn-sm">Detail</a>
                    <?php if(auth()->guard()->check()): ?> <?php if(Auth()->user()->role == 'admin'): ?>
                    <a href="/genre/<?php echo e($item->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" value="delete" class="btn btn-danger btn-sm">Delete</button>
                        <?php endif; ?>
                    <?php endif; ?>
                    </form>
                </tr>
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Tidak Ada Data Genre</td>
                </tr>

            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravelsanber\IM-Sanbercode-Laravel-Web-Dev\belajarlaravel\resources\views/genre/tampil.blade.php ENDPATH**/ ?>