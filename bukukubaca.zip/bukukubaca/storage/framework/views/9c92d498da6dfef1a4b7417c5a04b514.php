<?php $__env->startSection("title"); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <h1>Selamat Datang <?php echo e($full); ?></h1><br>
    <h2>Terimakasih sudah bergabung di Sanberbook. Social media kita bersama!</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravelsanber\IM-Sanbercode-Laravel-Web-Dev\belajarlaravel\resources\views/welcome.blade.php ENDPATH**/ ?>