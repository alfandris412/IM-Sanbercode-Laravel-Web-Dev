
<?php $__env->startSection("title"); ?>
    Detail Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <img src="<?php echo e(asset('image/'.$buku->gambar)); ?>" width="100%" height="500px" style="object-fit: contain; display: block; margin: 0 auto;" class="mb-5" alt="">
    <h1 class="text-primary"><?php echo e($buku->judul); ?></h1>
    <h4 class="text-secondary">Stock: <?php echo e($buku->stok); ?></h4>
    <p><?php echo e($buku->sumary); ?></p>
    <hr>
    <h1>List Komentar</h1>
    <?php $__empty_1 = true; $__currentLoopData = $buku->komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card my-3">
    <div class="card-header">
        <?php echo e($item->owner->nama); ?>

    </div>
    <div class="card-body">
        <p class="card-text"><?php echo e($item->content); ?></p>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>Tidak ada komentar</h3>
    <?php endif; ?>

    <hr>

    <h3>Buat Komentar</h3>
    <?php if(auth()->guard()->check()): ?>
    <form action="/komen/<?php echo e($buku->id); ?>" method="post" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    <div class="mb-3">
        <textarea name="content" class="form-control" rows="10" cols="30" placeholder="Isi Komentar"> </textarea>
    </div>
    <button type="submit" class="btn btn-primary">Kirim Komentar</button>
    </form><?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravelsanber\IM-Sanbercode-Laravel-Web-Dev\belajarlaravel\resources\views/buku/detail.blade.php ENDPATH**/ ?>