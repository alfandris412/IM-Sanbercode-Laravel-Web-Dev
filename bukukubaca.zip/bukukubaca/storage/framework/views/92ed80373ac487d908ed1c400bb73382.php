

<?php $__env->startSection("title"); ?>
    Detail Genre
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<h1 class="text-primary"><?php echo e($genre->nama); ?></h1>
<p><?php echo e($genre->deskripsi); ?></p>
<hr>
<div class="row mb-3">

<?php $__empty_1 = true; $__currentLoopData = $genre->buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 my-3" >
            <div class="card">
                <img class="img-fluid" src="<?php echo e(asset('image/' . $item->gambar)); ?>" alt="Card image top" style="height: 300px; object-fit: contain;">

                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                    <h6 class="card-subtitle mb-4">Stok: <?php echo e($item->stok); ?></h6>
                    <p class="card-text"><?php echo e(Str::limit($item->sumary, 100)); ?></p>

                    <div class="d-grid gap-2">
                        <a href="/buku/<?php echo e($item->id); ?>" class="btn btn-primary w-100">Baca Selengkapnya</a>
                    </div>
                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="ml-3">
    <h3> Tidak ada buku yang tersedia di Genre ini</h3>
    </div>
        
    <?php endif; ?>
    </div>
</div>
    

<a href="/genre" class="btn btn-secondary btn-sm my-3">Kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravelsanber\IM-Sanbercode-Laravel-Web-Dev\belajarlaravel\resources\views/genre/detail.blade.php ENDPATH**/ ?>