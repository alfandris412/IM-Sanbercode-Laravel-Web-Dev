

<?php $__env->startSection("title"); ?>
    Tambah Buku
<?php $__env->stopSection(); ?>
<?php $__env->startSection("keterangan_halaman"); ?>
    Di halaman ini anda bisa menambahkan buku
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <form action="/buku" method="post" enctype="multipart/form-data">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Genre</label><br>
            <select name="genres_id" id="" class="form-control">
                <option value="">--Pilih Genre--</option>
                <?php $__empty_1 = true; $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="">Tidak ada genre yang tersedia</option>
                <?php endif; ?>
            </select>
        </div> <br><br>
        <div class="mb-3">
            <label class="form-label">Judul Buku</label>
            <input type="text" name="judul" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Stock</label>
            <input type="number" name="stok" class="form-control">
        </div>
    <div class="mb-3">
        <label class="form-label">Ringkasan Buku</label>
        <textarea name="sumary" class="form-control" rows="10" cols="30"> </textarea>
    </div>
    <div class="mb-3">
        <label class="form-label">gambar</label>
        <input type="file" name="gambar" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravelsanber\IM-Sanbercode-Laravel-Web-Dev\belajarlaravel\resources\views/buku/create.blade.php ENDPATH**/ ?>