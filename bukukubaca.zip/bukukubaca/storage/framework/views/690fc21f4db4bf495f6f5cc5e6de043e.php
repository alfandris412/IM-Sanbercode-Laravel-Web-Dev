<?php $__env->startSection("title"); ?>
    Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('danger')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('danger')); ?>

        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <h4 style="color:grey">Selamat Datang <?php echo e(Auth()->user()->nama); ?>

         
        <?php if(Auth()->user()->profil): ?>
        (<?php echo e(Auth()->user()->profil->umur); ?> Tahun)
        <?php else: ?>
        <?php endif; ?>
        </h4> <hr>
    <?php endif; ?>
    <h1>BukuKuBaca</h1>
  
    <h2>Media Referensi Buku Terbaik</h2>
    <p>Membaca Adalah Pintu Awal Menuju Kesuksesan</p>
    <h3>Apa Isi Dari BukuKuBaca</h3>
    <ul>
        <li>Berbagai macam genre buku</li>
        <li>Ringkasan buku</li>
        <li>Forum referensi buku</li>
    </ul>
    <h3>Cara Bergabung ke BukuKuBaca</h3>
    <ol>
        <li>Mengunjungi Website kita</li>
        <li>Mendaftar Di <a href="/register">Form Sign Up</a></li>
        <li>Selesai!. Kamu sudah bisa mengakses berbai macam buku</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\laravelsanber\IM-Sanbercode-Laravel-Web-Dev\belajarlaravel\resources\views/home.blade.php ENDPATH**/ ?>