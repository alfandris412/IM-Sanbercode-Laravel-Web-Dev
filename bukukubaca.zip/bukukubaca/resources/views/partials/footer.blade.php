<!-- start footer Area -->
<footer class="footer-area" Style="Background-color:rgb(9, 26, 69); margin-top: 60px;">
<divy class="footer-bottom d-flex justify-content-center align-items-center flex-wrap">
<p class="footer-text m-0" style="
	padding-bottom: 40px;
"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Designed By Al Fandris <i class="fa fa-code" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
			
</divy>
</footer>
	<!-- End footer Area -->
