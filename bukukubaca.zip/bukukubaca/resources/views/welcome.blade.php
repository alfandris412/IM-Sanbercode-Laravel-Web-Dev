@extends('layouts.master')

@section("title")
    Dashboard
@endsection

@section("content")
    <h1>Selamat Datang {{$full}}</h1><br>
    <h2>Terimakasih sudah bergabung di Sanberbook. Social media kita bersama!</h2>
@endsection
